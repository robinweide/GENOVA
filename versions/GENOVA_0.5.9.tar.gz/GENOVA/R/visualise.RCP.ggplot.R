#' Plot the RCP results
#'
#' Produces a line-plot per chromosome.
#'
#' @param RCPdata Output of `RCP`
#' @return A ggplot-object
#' @export
visualise.RCP.ggplot <-function(RCPdata){
    cols <- RCPdata$color
    names(cols) <- RCPdata$sample
    ggplot2::ggplot(RCPdata, ggplot2::aes(col = sample, x = distance/1e6, 
        y = prob)) + ggplot2::geom_line() + 
        ggplot2::scale_x_log10() + ggplot2::scale_y_log10() + 
        ggplot2::facet_wrap(~chrom, nrow = floor(sqrt(length(unique(RCP_WTWAPL$chrom))))) + 
        ggplot2::theme_linedraw() + ggplot2::scale_color_manual(values = cols) + 
        ggplot2::labs(title = "Relative contact probability", 
            x = "Distance (Mbp)", y = "RCP", col = "") + ggplot2::theme(aspect.ratio = 1) + 
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90,vjust = 0.5, hjust=1))
}
